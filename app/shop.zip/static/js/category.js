$(document).ready(function () {
    $("#submit").click(function () {
        if ($("#a_category").val() == "") {
            alert("please enter category:")
            $("#a_category").focus();
            return false;
        }


        let formData = new FormData();
        formData.append("a_category", $("#a_category").val());

        formData.append("csrfmiddlewaretoken", $("input[name=csrfmiddlewaretoken]").val());

        $.ajax({
            url: "/add_category/",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (res) {
                if (res == "10") {
                    alert("Category already exist");
                }
                else {
                    alert("Category added successfully!");
                }
                // alert("email Submitted");
            },
            error: function (error) {
                console.log(error);
            },
            complete: function () {
                console.log("completed")
            }
        });
    });
});


function getcategory() {
    let formData = new FormData();
    formData.append("csrfmiddlewaretoken", $("input[name=csrfmiddlewaretoken]").val());

    $.ajax({
        url: "/display_category/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
            for (let i = 0; i < res.length; i++)
                $("#table").append("<tr><td>" + res[i].ct_id + "</td><td>" + res[i].ct_name + "</td></tr>");
            console.log(res)
        },
        error: function (error) {
        },
        complete: function () {
        },
    });
}
getcategory();