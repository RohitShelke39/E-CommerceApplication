$(document).ready(function () {
    $("#submit").click(function () {
        if ($("#a_subcategory").val() == "") {
            alert("please enter sub-category:")
            $("#a_subcategory").focus();
            return false;
        }
        if ($("#a_category").val() == "") {
            alert("please enter category:")
            $("#a_category").focus();
            return false;
        }
        if ($("#prodname").val() == "") {
            alert("please enter product name:")
            $("#prodname").focus();
            return false;
        }
        if ($("#prodesc").val() == "") {
            alert("please enter product description:")
            $("#prodesc").focus();
            return false;
        }
        if ($("#prodprice").val() == "") {
            alert("please enter product price:")
            $("#prodprice").focus();
            return false;
        }
        if ($("#prodimg").val() == "") {
            alert("please enter product iamge:")
            $("#prodimg").focus();
            return false;
        }


        let formData = new FormData();
        formData.append("a_category", $("#a_category").val());
        formData.append("a_subcategory", $("#a_subcategory").val());
        formData.append("prodname", $("#prodname").val());
        formData.append("prodesc", $("#prodesc").val());
        formData.append("prodprice", $("#prodprice").val());
        formData.append("prodimg", $("#prodimg").val());



        formData.append("csrfmiddlewaretoken", $("input[name=csrfmiddlewaretoken]").val());

        $.ajax({
            url: "/add_subcategory/",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (res) {
                if (res == "10") {
                    alert("Product already exist");
                }
                else {
                    alert("Product added successfully!");
                }
                // alert("email Submitted");
            },
            error: function (error) {
                console.log(error);
            },
            complete: function () {
                console.log("completed")
            }
        });
    });
});


function getproduct() {
    let formData = new FormData();
    formData.append("csrfmiddlewaretoken", $("input[name=csrfmiddlewaretoken]").val());

    $.ajax({
        url: "/display_product/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
            for (let i = 0; i < res.length; i++)
                $("#table").append("<tr><td>" + res[i].sc_id + "</td><td>" + res[i].sc_ct_name + "</td><td>" + res[i].sc_name + "</td></tr>");
            console.log(res)
        },
        error: function (error) {
        },
        complete: function () {
        },
    });
}
getproduct();