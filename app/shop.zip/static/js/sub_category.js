$(document).ready(function () {
    $("#submit").click(function () {
        if ($("#a_sc_category").val() == "") {
            alert("please enter category:")
            $("#a_sc_category").focus();
            return false;
        }
        if ($("#a_subcategory").val() == "") {
            alert("please enter sub-category:")
            $("#a_subcategory").focus();
            return false;
        }



        let formData = new FormData();
        formData.append("a_sc_category", $("#a_sc_category").val());
        formData.append("a_subcategory", $("#a_subcategory").val());

        formData.append("csrfmiddlewaretoken", $("input[name=csrfmiddlewaretoken]").val());

        $.ajax({
            url: "/add_subcategory/",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (res) {
                if (res == "10") {
                    alert("SubCategory already exist");
                }
                else {
                    alert("SubCategory added successfully!");
                }
                // alert("email Submitted");
            },
            error: function (error) {
                console.log(error);
            },
            complete: function () {
                console.log("completed")
            }
        });
    });
});


function getsubcategory() {
    let formData = new FormData();
    formData.append("csrfmiddlewaretoken", $("input[name=csrfmiddlewaretoken]").val());

    $.ajax({
        url: "/display_subcategory/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
            for (let i = 0; i < res.length; i++)
                $("#table").append("<tr><td>" + res[i].sc_id + "</td><td>" + res[i].sc_ct_name + "</td><td>" + res[i].sc_name + "</td></tr>");
            console.log(res)
        },
        error: function (error) {
        },
        complete: function () {
        },
    });
}
getsubcategory();